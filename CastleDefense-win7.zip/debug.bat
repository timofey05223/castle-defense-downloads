@echo off

cd /d "%~dp0"

CastleDefense_Win7.exe --verbose > debug_log.txt 2>&1

echo exit code: %ERRORLEVEL% >> debug_log.txt

notepad debug_log.txt

