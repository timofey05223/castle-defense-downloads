@echo off

rem Windows 7 / old PCs: start with OpenGL instead of Vulkan/DirectX 12

start "" "%~dp0CastleDefense.exe" --rendering-driver opengl3

